import random
from tkinter import *
from tkinter import messagebox

# Generate random number
random_number = random.randint(1, 100)
attempts = 0

# Function to check guess
def check_guess():
    global attempts

    try:
        guess = int(entry_guess.get())
        attempts += 1

        if guess < random_number:
            result_label.config(
                text="📉 Too Low! Try Again.",
                fg="orange"
            )

        elif guess > random_number:
            result_label.config(
                text="📈 Too High! Try Again.",
                fg="red"
            )

        else:
            result_label.config(
                text=f"🎉 Correct! You guessed it in {attempts} attempts.",
                fg="lightgreen"
            )

    except ValueError:
        messagebox.showerror(
            "Invalid Input",
            "Please enter a valid number!"
        )

# Restart Game
def restart_game():
    global random_number, attempts

    random_number = random.randint(1, 100)
    attempts = 0

    entry_guess.delete(0, END)

    result_label.config(
        text="Game Restarted! Guess Again 🔄",
        fg="cyan"
    )

# Main Window
root = Tk()
root.title("Guess The Number Game")
root.geometry("500x500")
root.config(bg="#1e1e2f")

# Heading
heading = Label(
    root,
    text="🎯 Guess The Number 🎯",
    font=("Arial", 24, "bold"),
    bg="#1e1e2f",
    fg="white"
)
heading.pack(pady=20)

# Instructions
instruction = Label(
    root,
    text="Guess a number between 1 and 100",
    font=("Arial", 14),
    bg="#1e1e2f",
    fg="lightgray"
)
instruction.pack(pady=10)

# Entry Box
entry_guess = Entry(
    root,
    font=("Arial", 18),
    justify="center",
    width=15
)
entry_guess.pack(pady=20)

# Guess Button
guess_btn = Button(
    root,
    text="Check Guess",
    font=("Arial", 14, "bold"),
    bg="#00b894",
    fg="white",
    padx=20,
    pady=10,
    command=check_guess
)
guess_btn.pack(pady=10)

# Restart Button
restart_btn = Button(
    root,
    text="Restart Game",
    font=("Arial", 14, "bold"),
    bg="#0984e3",
    fg="white",
    padx=20,
    pady=10,
    command=restart_game
)
restart_btn.pack(pady=10)

# Result Label
result_label = Label(
    root,
    text="",
    font=("Arial", 16, "bold"),
    bg="#1e1e2f"
)
result_label.pack(pady=30)

# Footer
footer = Label(
    root,
    text="Made by Nani 💜",
    font=("Arial", 10),
    bg="#1e1e2f",
    fg="gray"
)
footer.pack(side="bottom", pady=10)

# Run App
root.mainloop()