import tkinter as tk
from tkinter import messagebox
import json
import os

FILE_NAME = "contacts.json"

# -------------------- Functions --------------------

def load_contacts():
    if os.path.exists(FILE_NAME):
        with open(FILE_NAME, "r") as file:
            return json.load(file)
    return []

def save_contacts():
    with open(FILE_NAME, "w") as file:
        json.dump(contacts, file, indent=4)

def update_listbox():
    contact_list.delete(0, tk.END)

    for contact in contacts:
        contact_list.insert(
            tk.END,
            f"👤 {contact['name']} | 📞 {contact['phone']} | 📧 {contact['email']}"
        )

    counter_label.config(text=f"Total Contacts: {len(contacts)}")

def add_contact():
    name = name_entry.get()
    phone = phone_entry.get()
    email = email_entry.get()

    if not name or not phone or not email:
        messagebox.showwarning("Warning", "Please fill all fields!")
        return

    contacts.append({
        "name": name,
        "phone": phone,
        "email": email
    })

    save_contacts()
    update_listbox()

    name_entry.delete(0, tk.END)
    phone_entry.delete(0, tk.END)
    email_entry.delete(0, tk.END)

def delete_contact():
    try:
        selected = contact_list.curselection()[0]
        del contacts[selected]

        save_contacts()
        update_listbox()

    except:
        messagebox.showerror("Error", "Select a contact first!")

# -------------------- Window --------------------

root = tk.Tk()
root.title("📇 Contact Management System")
root.geometry("700x600")
root.configure(bg="#1E1E2F")

# Title
title = tk.Label(
    root,
    text="📇 CONTACT MANAGEMENT SYSTEM",
    font=("Arial", 22, "bold"),
    bg="#1E1E2F",
    fg="white"
)
title.pack(pady=15)

# Form Frame
form_frame = tk.Frame(root, bg="#2D2D44")
form_frame.pack(pady=10, padx=20, fill="x")

tk.Label(form_frame, text="Name", bg="#2D2D44", fg="white").grid(row=0, column=0, padx=10, pady=10)
name_entry = tk.Entry(form_frame, width=40)
name_entry.grid(row=0, column=1)

tk.Label(form_frame, text="Phone", bg="#2D2D44", fg="white").grid(row=1, column=0, padx=10, pady=10)
phone_entry = tk.Entry(form_frame, width=40)
phone_entry.grid(row=1, column=1)

tk.Label(form_frame, text="Email", bg="#2D2D44", fg="white").grid(row=2, column=0, padx=10, pady=10)
email_entry = tk.Entry(form_frame, width=40)
email_entry.grid(row=2, column=1)

# Buttons
button_frame = tk.Frame(root, bg="#1E1E2F")
button_frame.pack(pady=15)

add_btn = tk.Button(
    button_frame,
    text="➕ Add Contact",
    bg="#00C853",
    fg="white",
    font=("Arial", 11, "bold"),
    command=add_contact
)
add_btn.grid(row=0, column=0, padx=10)

delete_btn = tk.Button(
    button_frame,
    text="🗑 Delete Contact",
    bg="#D50000",
    fg="white",
    font=("Arial", 11, "bold"),
    command=delete_contact
)
delete_btn.grid(row=0, column=1, padx=10)

# Contact List
list_frame = tk.Frame(root)
list_frame.pack(pady=10)

scrollbar = tk.Scrollbar(list_frame)
scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

contact_list = tk.Listbox(
    list_frame,
    width=90,
    height=15,
    font=("Arial", 10),
    yscrollcommand=scrollbar.set
)
contact_list.pack()

scrollbar.config(command=contact_list.yview)

# Counter
counter_label = tk.Label(
    root,
    text="Total Contacts: 0",
    font=("Arial", 12, "bold"),
    bg="#1E1E2F",
    fg="#00E5FF"
)
counter_label.pack(pady=10)

# Footer
footer = tk.Label(
    root,
    text="Developed by Nani 💙",
    bg="#1E1E2F",
    fg="lightgray"
)
footer.pack(side="bottom", pady=10)

contacts = load_contacts()
update_listbox()

root.mainloop()