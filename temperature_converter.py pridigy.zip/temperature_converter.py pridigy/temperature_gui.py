from tkinter import *
from tkinter import messagebox

# Function for temperature conversion
def convert_temperature():
    try:
        temp = float(entry_temp.get())
        unit = unit_var.get()

        if unit == "Celsius":
            fahrenheit = (temp * 9/5) + 32
            kelvin = temp + 273.15

            result_label.config(
                text=f"🔥 Fahrenheit: {round(fahrenheit,2)} °F\n❄️ Kelvin: {round(kelvin,2)} K"
            )

        elif unit == "Fahrenheit":
            celsius = (temp - 32) * 5/9
            kelvin = celsius + 273.15

            result_label.config(
                text=f"🌡️ Celsius: {round(celsius,2)} °C\n❄️ Kelvin: {round(kelvin,2)} K"
            )

        elif unit == "Kelvin":
            celsius = temp - 273.15
            fahrenheit = (celsius * 9/5) + 32

            result_label.config(
                text=f"🌡️ Celsius: {round(celsius,2)} °C\n🔥 Fahrenheit: {round(fahrenheit,2)} °F"
            )

    except ValueError:
        messagebox.showerror("Invalid Input", "Please enter a valid number!")

# Main Window
root = Tk()
root.title("Advanced Temperature Converter")
root.geometry("500x500")
root.config(bg="#1e1e2f")

# Heading
heading = Label(
    root,
    text="🌡️ Temperature Converter 🌡️",
    font=("Arial", 20, "bold"),
    bg="#1e1e2f",
    fg="white"
)
heading.pack(pady=20)

# Temperature Entry
Label(
    root,
    text="Enter Temperature:",
    font=("Arial", 14),
    bg="#1e1e2f",
    fg="white"
).pack()

entry_temp = Entry(
    root,
    font=("Arial", 14),
    width=20,
    justify="center"
)
entry_temp.pack(pady=10)

# Dropdown Menu
unit_var = StringVar()
unit_var.set("Celsius")

Label(
    root,
    text="Select Unit:",
    font=("Arial", 14),
    bg="#1e1e2f",
    fg="white"
).pack()

dropdown = OptionMenu(
    root,
    unit_var,
    "Celsius",
    "Fahrenheit",
    "Kelvin"
)

dropdown.config(font=("Arial", 12))
dropdown.pack(pady=10)

# Convert Button
convert_btn = Button(
    root,
    text="Convert",
    font=("Arial", 14, "bold"),
    bg="#00b894",
    fg="white",
    padx=20,
    pady=10,
    command=convert_temperature
)
convert_btn.pack(pady=20)

# Result Label
result_label = Label(
    root,
    text="",
    font=("Arial", 16, "bold"),
    bg="#1e1e2f",
    fg="#ffeaa7"
)
result_label.pack(pady=20)

# Footer
footer = Label(
    root,
    text="Made by Nani 💜",
    font=("Arial", 10),
    bg="#1e1e2f",
    fg="gray"
)
footer.pack(side="bottom", pady=10)

# Run App
root.mainloop()